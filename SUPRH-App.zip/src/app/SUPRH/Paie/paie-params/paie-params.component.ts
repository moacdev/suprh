import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-paie-params',
  templateUrl: './paie-params.component.html',
  styleUrls: ['./paie-params.component.css']
})
export class PaieParamsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
