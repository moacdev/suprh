import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-paie-employes',
  templateUrl: './paie-employes.component.html',
  styleUrls: ['./paie-employes.component.css']
})
export class PaieEmployesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
