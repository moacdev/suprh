import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-paie-conges',
  templateUrl: './paie-conges.component.html',
  styleUrls: ['./paie-conges.component.css']
})
export class PaieCongesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
