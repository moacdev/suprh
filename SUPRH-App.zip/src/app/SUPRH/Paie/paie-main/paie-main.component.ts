import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-paie-main',
  templateUrl: './paie-main.component.html',
  styleUrls: ['./paie-main.component.css']
})
export class PaieMainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
