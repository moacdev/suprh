import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-paie-codification',
  templateUrl: './paie-codification.component.html',
  styleUrls: ['./paie-codification.component.css']
})
export class PaieCodificationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
