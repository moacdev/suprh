import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-paie-utilisateurs',
  templateUrl: './paie-utilisateurs.component.html',
  styleUrls: ['./paie-utilisateurs.component.css']
})
export class PaieUtilisateursComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
